clc 
close all
clear all
%% Dimentions
n=3;   
o=3;
m=1;   
r=2;  
%% System matrices
A{1} = [ 1.0574 0 0;
        -0.0574 1 0;
        -0.0605 -0.4 1];
A{2} = [ 1.0574 0 0;
        -0.0574 1 0;
        -0.0963 -6.6366 0];     
B{1} = [-0.1482; 0.0053; 0.0046];
B{2} = [-0.1482; 0.0053; 0.0073];
E{1} = [1; 0; 0];
E{2} = E{1};
C2{1} = [0 1 0];
C2{2} = C2{1};
D = [ 0.05 0 0;
      0 0.05 0;
      0 0 0.05]; 
Ea{1}=[ 0.5091 0 0;
        -0.5091 0 0;
        0.5091 0 0]; 
Ea{2}=[ 0.5091 0 0;
        -0.5091 0 0;
        0.8107 0 0];  
Eb{1}= [-0.3571; 0; 0];   
Eb{2}=Eb{1};  
 %% Parameters
xi_1=0.08;
xi_2=100000000.;
xi_3=0.0010;
xi_4=0.001;
xi_5=0.0010;
setlmis([]);
gamma_2=lmivar(1,[1 1]);
Psi = lmivar(2,[o o]);
lambda_a = lmivar(1,[n 1]);
lambda_b = lmivar(1,[1 1]);
P=lmivar(1,[n 1]);
for j=1:r
    K{j}=lmivar(2,[1 n]);
    M{j}=lmivar(2,[1 n]);
    Q{j}=lmivar(2,[n 1]);
end
%% LMI
num = 0;
num = num + 1;
lmiterm([-num 1 1 P],1,1);
%%
for i = 1:r
    for j = 1:r
            num = num +1;
            lmiterm([num 1 1 P],-1,1);
            lmiterm([num 1 1 lambda_a],1,1);     
            lmiterm([num 1 3 -Psi],A{i},1);
            lmiterm([num 1 3 M{j}],B{i},1);
            lmiterm([num 1 4 0],C2{i}');
            lmiterm([num 1 5 0],Ea{i}');
            lmiterm([num 1 6 -K{j}],1,Eb{i}');
            lmiterm([num 1 7 0],D);
            lmiterm([num 1 8 0],D);
            lmiterm([num 2 2 P],E{i}',E{i});
            lmiterm([num 2 2 gamma_2],-1,1);
            lmiterm([num 2 2 lambda_b],1,1); 
            lmiterm([num 3 3 Psi],-1,1,'s');
            lmiterm([num 3 3 P],1,1);
            lmiterm([num 4 4 0],-1);
            lmiterm([num 5 5 0],-xi_1\1);
            lmiterm([num 6 6 0],-xi_2\1);
            lmiterm([num 7 7 0],-xi_1);     
            lmiterm([num 8 8 0],-xi_2); 
    end
end
%% 
for i = 1:r
    for j = 1:r
            num = num +1;
            lmiterm([num 1 1 lambda_a],-1,1);    
            lmiterm([num 1 3 0],A{i}');
            lmiterm([num 1 3 -K{j}],1,B{i}');
            lmiterm([num 1 4 0],D');
            lmiterm([num 1 5 0],D');          
            lmiterm([num 2 2 lambda_b],-1,1); 
            lmiterm([num 2 6 P],E{i}',1);
            lmiterm([num 2 7 P],E{i}',Ea{i}');
            lmiterm([num 2 8 Q{j}],E{i}',Eb{i}');
            lmiterm([num 3 3 0],-xi_3\1);
            lmiterm([num 4 4 0],-xi_4\1);
            lmiterm([num 5 5 0],-xi_5\1);     
            lmiterm([num 6 6 0],-xi_3); 
            lmiterm([num 7 7 0],-xi_4); 
            lmiterm([num 8 8 0],-xi_5); 
    end
end
%% 
lmisys = getlmis;
dim = decnbr(lmisys);
c = zeros(dim,1);
c(1) = 1;
c(2) = 1;
options = [0 0 0 0 0];
[copt,xopt] = mincx(lmisys,c,options);
%% 
for j=1:r    
    K{j} = dec2mat(lmisys,xopt,K{j});
end
P = dec2mat(lmisys,xopt,P);
gamma_2 = dec2mat(lmisys,xopt,gamma_2);
gamma = sqrt(gamma_2);
