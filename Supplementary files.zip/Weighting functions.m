%% Weighting functions
clc
clear
%% 
x = -1.2*pi:0.01:1.2*pi;
%%
h0=1./(1+exp(-3.*(x-0.5.*pi)));
h2=1./(1+exp(-3.*(x+0.5.*pi)));
h1 =(1-h0).*h2;
h2 = 1-h1;
plot (x,h1,'-',x,h2,'--')
ylabel('$h_i$','interpreter','latex');
xlabel('$\theta(t)$','interpreter','latex');
legend({'$h_1$','$h_2$'},'interpreter','latex')
axis([-1.2*pi 1.2*pi -inf inf]);