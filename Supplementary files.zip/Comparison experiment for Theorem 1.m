clc 
close all
clear all
%%  Dimentions
n=3;  
o=3;
m=1;   
r=2;  
%%  System matrices
A{1} = [ 0.7273 0 0;
        -0.7273 0 0;
        -0.7273 -4 0];
A{2} = [ 0.7273 0 0;
        -0.7273 0 0;
        -1.1574 -6.3662 0];    
B{1} = [-1.4286; 0; 0];
B{2} = B{1};
E{1} = [1; 0; 0];
E{2} = E{1};
C2{1} = [0 1 0];
C2{2} = C2{1};
D = [ 0.05 0 0;
      0 0.05 0;
      0 0 0.05]; 
Ea{1}=[ 0.5091 0 0;
        -0.5091 0 0;
        0.5091 0 0]; 
Ea{2}=[ 0.5091 0 0;
        -0.5091 0 0;
        0.8107 0 0];  
Eb{1}= [-0.3571; 0; 0];   
Eb{2}=Eb{1};  
 %% Parameters
xi_1=10;
xi_2=100;
setlmis([]);
gamma_2=lmivar(1,[1 1]);
N=lmivar(1,[n 1]);
for j=1:r
    Q{j}=lmivar(2,[m o]);
end
%% LMI
num = 0;
num = num + 1;
lmiterm([-num 1 1 N],1,1);
%% 
for i = 1:r
    for j = 1:r
            num = num +1;
            lmiterm([num 1 1 N],A{i},1,'s');
            lmiterm([num 1 1 Q{j}],B{i},1,'s');
            lmiterm([num 1 2 0],D);       
            lmiterm([num 1 3 N],1,Ea{i}');
            lmiterm([num 1 4 0],D);      
            lmiterm([num 1 5 -Q{j}],1,Eb{i}');
            lmiterm([num 1 6 0],E{i});
            lmiterm([num 1 7 N],1,C2{i}');
            lmiterm([num 2 2 0],-xi_1\1);
            lmiterm([num 3 3 0],-xi_1);
            lmiterm([num 4 4 0],-xi_2\1);
            lmiterm([num 5 5 0],-xi_2);
            lmiterm([num 6 6 gamma_2],-1,1);
            lmiterm([num 7 7 0],-1);       
    end
end
%% 
lmisys = getlmis;
dim = decnbr(lmisys);
c = zeros(dim,1);
c(1) = 1;
c(2) = 1;
options = [0 0 0 0 0];
[copt,xopt] = mincx(lmisys,c,options);
%%
for j=1:r    
    Q{j} = dec2mat(lmisys,xopt,Q{j});
    K{j} = Q{j}*inv(N);
end
N = dec2mat(lmisys,xopt,N);
gamma_2 = dec2mat(lmisys,xopt,gamma_2);
gamma = sqrt(gamma_2);
