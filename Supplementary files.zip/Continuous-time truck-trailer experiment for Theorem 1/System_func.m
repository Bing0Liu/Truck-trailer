function r = System_func(A,B,E,D,F,Ea,Eb,x,u,omega)

r = A*x+D*F*Ea*x+B*u+D*F*Eb*u+E*omega;
