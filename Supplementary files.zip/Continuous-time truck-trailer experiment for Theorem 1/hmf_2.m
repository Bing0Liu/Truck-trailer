function r = hmf_3(x3,paras)

r = 1-hmf_1(x3);


