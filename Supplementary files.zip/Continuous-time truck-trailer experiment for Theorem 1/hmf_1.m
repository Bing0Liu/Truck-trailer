function r = hmf_1(x3,paras)

r = (1-1/(1+exp(-3*(x3-0.5*pi))))*(1/(1+exp(-3*(x3-0.5*pi))));


