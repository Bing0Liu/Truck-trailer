%% liubing/Daniel-202308 TASE-Theorem1 discrete time domain simulation
clc
clear all
close all
global A B E D F Ea Eb omega r row column u M N;
%% program parameters
jt = 40;
Ts = 0.5;
%% System parameters
A{1} = [ 0.7273 0 0;
        -0.7273 0 0;
        -0.7273 -4 0];
A{2} =  [ 0.7273 0 0;
        -0.7273 0 0;
        -1.1574 -6.3662 0];
B{1} =  [-1.4286; 0; 0];
B{2} =  [-1.4286; 0; 0];
E{1} = [1; 0; 0];
E{2} = E{1};
C2{1} = [0 1 0];
C2{2} = C2{1};
D{1} = [ 0.05 0 0;
      0 0.05 0;
      0 0 0.05]; 
D{2} = D{1};  
F = sin(0.1*jt)*exp(-0.1*jt);
Ea{1}=[ 0.5091 0 0;
        -0.5091 0 0;
        0.5091 0 0]; 
Ea{2}=[ 0.5091 0 0;
        -0.5091 0 0;
        0.8107 0 0];  
Eb{1}= [-0.3571; 0; 0];   
Eb{2}=Eb{1};  
%% code
r = 2; 
row = 3;
column = 1;
jj=0;
%% Initialize the system states and parameters
x1 = 1;
x2 = 1;
x3 = 1;
x = [x1 x2 x3];
%% For figure
    t_draw = zeros(1,jt);
    u_draw = zeros(1,jt);
    V_draw = zeros(1,jt);
    x_draw = zeros(3,jt);
%% RK4 Solution
for i = 1:jt

     K{1} = [58.7134,-81.1586,11.8845];
     K{2} = [57.7115,-79.9523,11.3105];  
   
   hmf = [hmf_1(x(1)) hmf_2(x(1))];
   KK = zeros(column,row);
    for j = 1:r
        KK = KK+hmf(j)*K{j};
    end
    u = KK*x(end,:)';
    omega = sin(0.1*jt)*exp(-0.1*jt);
    [t,x] = ode45(@dx_func,[Ts*(i-1) Ts*i], x(end,:)');
    %% Figure Data
    t_draw(:,i) = Ts*i;
    u_draw(:,i) = u;
    x_draw(:,i) = x(end,:)';
end
x_draw=[[x1;x2;x3] x_draw];
plot3(x_draw(1,:),x_draw(2,:),x_draw(3,:));hold on;
xlabel('$x_1$','interpreter','latex'); ylabel('$x_2$','interpreter','latex');  zlabel('$x_3$','interpreter','latex');grid on;% 
hold on;
plot(0,0,'r*');
scatter3(x_draw(1,1),x_draw(2,1),x_draw(3,1),'bo'); hold on; axis tight;

     K{1} = [58.7134,-81.1586,11.8845];
     K{2} = [57.7115,-79.9523,11.3105];   

num = 20;
x1 = linspace(-2,2,num);
x2 = linspace(-2,2,num);
x3 = linspace(-5,5,num);
%% RK4 Solution
for i = 1:num
    for j = 1:num
        for q = 1:num

     K{1} = [58.7134,-81.1586,11.8845];
     K{2} = [57.7115,-79.9523,11.3105];  
        
        hmf = [hmf_1(x1(i)) hmf_2(x1(i))];
        KKK = zeros(column,row);
        for k = 1:r
            KKK = KKK+hmf(k)*K{k};
        end
        u = KKK*[x1(i); x2(j);x3(q)];
          dx = zeros(3,1);
          for k = 1:2
              dx = dx+hmf(k)*(A{k}*[x1(i); x2(j);x3(q)]+D{k}*F*Ea{k}*[x1(i); x2(j);x3(q)]+B{k}*u+D{k}*F*Eb{k}*u+E{k}*omega);
          end
          dx_data(i,j,q) = dx(1);
          dy_data(i,j,q) = dx(2);
          dz_data(i,j,q) = dx(3);
        end
    end
end
[x1,x2,x3] = meshgrid(x1',x2',x3');
quiver3(x1,x2,x3,dx_data,dy_data,dz_data);hold on;
xlabel('$x_1$','interpreter','latex'); ylabel('$x_2$','interpreter','latex');zlabel('$x_3$','interpreter','latex'); grid on;

figure(2)
subplot(311); 
plot([0 t_draw],x_draw(1,:),'linewidth',1.5);
set(gca, 'Fontname', 'Times New Roman','FontSize',14);
ylabel('$x_1$','fontsize',14,'interpreter','latex'); 
xlabel('$t(s)$','fontsize',14,'interpreter','latex')
grid on;  
stairs(x_draw(1,:),'linewidth',1.5)
axis([0 40 -0.5 2]);
ylabel('$x_1$','fontsize',14,'interpreter','latex'); 
xlabel('$t(s)$','fontsize',14,'interpreter','latex')

subplot(312); 
plot([0 t_draw],x_draw(2,:),'linewidth',1.5);
set(gca, 'Fontname', 'Times New Roman','FontSize',14);
ylabel('$x_2$','fontsize',14,'interpreter','latex'); 
xlabel('$t(s)$','fontsize',14,'interpreter','latex')
grid on; 
stairs(x_draw(2,:),'linewidth',1.5) 
axis([0 40 -0.5 2]);
ylabel('$x_2$','fontsize',14,'interpreter','latex'); 
xlabel('$t(s)$','fontsize',14,'interpreter','latex')

subplot(313); 
plot([0 t_draw],x_draw(3,:),'linewidth',1.5);
set(gca, 'Fontname', 'Times New Roman','FontSize',14); 
ylabel('$x_3$','fontsize',14,'interpreter','latex'); 
xlabel('$t(s)$','fontsize',14,'interpreter','latex')
grid on; 
stairs(x_draw(3,:),'linewidth',1.5)
axis([0 40 -5 5]);
ylabel('$x_3$','fontsize',14,'interpreter','latex'); 
xlabel('$t(s)$','fontsize',14,'interpreter','latex')