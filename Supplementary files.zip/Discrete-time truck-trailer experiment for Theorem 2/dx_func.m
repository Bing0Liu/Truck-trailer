function result = dx_func(t,x)
global A B E D F Ea Eb omega r row column u M N;

     K{1} = [58.7134,-81.1586,11.8845];
     K{2} = [57.7115,-79.9523,11.3105];    

hmf = [hmf_1(x(1)) hmf_2(x(1))];
AA = zeros(row,row);
BB = zeros(row,column);
EE = zeros(row,column);
KK = zeros(column,row);

for j = 1:r
    AA = AA+hmf(j)*A{j};
    BB = BB+hmf(j)*B{j};
    EE = EE+hmf(j)*E{j};
    KK = KK+hmf(j)*K{j};       
end
u = KK*x;
result = AA*x+D{1}*F*Ea{1}*x+D{2}*F*Ea{2}*x+BB*u+D{1}*F*Eb{1}*u+D{2}*F*Eb{2}*u+EE*omega;