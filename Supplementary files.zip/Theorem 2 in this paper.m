clc 
close all
clear all
%%  Dimentions
n=3; 
o=3;
m=1;   
r=2;  
v=1;
%%  System matrices
A{1} = [ 1.0574 0 0;
        -0.0754 1 0;
        -0.0605 -0.4 1];
A{2} = [ 1.0754 0 0;
        -0.0754 1 0;
        -0.0963 -6.6366 1];     
B{1} = [-0.1482; 0.0053; 0.0046];
B{2} = [-0.1482; 0.0053; 0.0073];
E{1} = [1; 0; 0];
E{2} = E{1};
C2{1} = [0 1 0];
C2{2} = C2{1};
D = [ 0.05 0 0;
      0 0.05 0;
      0 0 0.05]; 
Da{1} = [ 0.05 0 0;
      0 0.05 0;
      0 0 0.05]; 
Da{2} = [ 0.05 0 0;
      0 0.05 0;
      0 0 0.05]; 
Db{1} = [ 0.05 0 0;
      0 0.05 0;
      0 0 0.05]; 
Db{2} = [ 0.05 0 0;
      0 0.05 0;
      0 0 0.05]; 
Ea{1}=[ 0.5091 0 0;
        -0.5091 0 0;
        0.5091 0 0]; 
Ea{2}=[ 0.5091 0 0;
        -0.5091 0 0;
        0.8107 0 0];  
Eb{1}= [-0.3571; 0; 0];   
Eb{2}=Eb{1};  
 %% Parameters
kappa_1=0.10;
kappa_2=10.100;
kappa_3=10.10;
kappa_4=10.10;
kappa_5=10.10;
rho_1=0.0010;
rho_2=0.000000001;
rho_3=0.001;
rho_4=10.0001;
rho_5=110.1;
rho_6=1.001;
rho_7=10.001;
rho_8=1.001;
rho_9=10.001;
rho_10=0.01;
setlmis([]);
gamma_2 = lmivar(1,[1 1]);
Psi = lmivar(2,[o o]);
Omega = lmivar(2,[o o]);
Omega_1 = lmivar(2,[o o]);
Omega_2 = lmivar(2,[o o]);
IPsi = inv(Psi);
Phi_1 = lmivar(2,[o o]);
Phi_2 = lmivar(2,[o o]);
P=lmivar(1,[n 1]);
for i=1:r
    for j=1:r
        phi_1{i,j}=lmivar(1,[n 1]);
        phi_2{i,j}=lmivar(1,[n 1]);
        phi_3{i,j}=lmivar(1,[n 1]);
        phi_4{i,j}=lmivar(1,[n 1]);
        phi_5{i,j}=lmivar(1,[n 1]);
        Gamma_1{i,j} = lmivar(1,[v 1]);
        Gamma_2{i,j} = lmivar(1,[v 1]);
        Gamma_3{i,j} = lmivar(1,[v 1]);
        Gamma_4{i,j} = lmivar(1,[v 1]);
        Gamma_5{i,j} = lmivar(1,[v 1]);
        Gamma_6{i,j} = lmivar(1,[v 1]);
        Gamma_7{i,j} = lmivar(1,[v 1]);
        Gamma_8{i,j }= lmivar(1,[v 1]);
        Gamma_9{i,j} = lmivar(1,[v 1]);
        Gamma_10{i,j} = lmivar(1,[v 1]);
        M_1{i,j} = lmivar(1,[n 1]);
        M_2{i,j} = lmivar(1,[n 1]);
        M_3{i,j} = lmivar(1,[n 1]);
        M_4{i,j} = lmivar(1,[n 1]);
        M_5{i,j} = lmivar(1,[n 1]);
        W_1{i,j}=lmivar(2,[n n]);
        W_2{i,j}=lmivar(2,[n n]);
        W_3{i,j}=lmivar(2,[n n]);
        W_4{i,j}=lmivar(2,[n n]);
        W_5{i,j}=lmivar(2,[n n]);
    end
end
for j=1:r
    Z{j}=lmivar(2,[m o]);
    K{j}=lmivar(2,[m o]);
end
%% LMI
num = 0;
num = num + 1;
lmiterm([-num 1 1 P],1,1);
%% 
for i = 1:r
        num = num +1;
        lmiterm([num 1 1 phi_1{i}],kappa_1,1);  
        lmiterm([num 1 1 phi_2{i}],kappa_2,1);  
end
for i = 1:r
        num = num +1;
        lmiterm([num 1 1 phi_3{i}],kappa_3,1);  
        lmiterm([num 1 1 phi_4{i}],kappa_4,1);  
        lmiterm([num 1 1 phi_5{i}],kappa_5,1);  
end
%% 
for i = 1:r
    for j = 1:r
            num = num +1;
            lmiterm([num 1 1 M_1{i,j}],1,1);
            lmiterm([num 1 1 W_1{i,j}],-1,1,'s');
            lmiterm([num 1 2 -W_1{i,j}],1,1); 
            lmiterm([num 1 2 phi_1{i,j}],0.5*kappa_1,1); 
            lmiterm([num 1 3 0],Ea{1}');    
            lmiterm([num 2 2 M_1{i,j}],-1,1);
            lmiterm([num 2 4 Psi],1,Da{i});  
            lmiterm([num 3 3 0],-2*rho_1);
            lmiterm([num 3 3 Gamma_1{i,j}],rho_1*rho_1,1);
            lmiterm([num 4 4 0],-2*rho_2);
            lmiterm([num 4 4 Gamma_2{i,j}],rho_2*rho_2,1);     
    end
end
%% 
for i = 1:r
    for j = 1:r
            num = num +1;
            lmiterm([num 1 1 M_2{i,j}],1,1);
            lmiterm([num 1 1 W_2{i,j}],-1,1,'s');
            lmiterm([num 1 2 -W_2{i,j}],1,1); 
            lmiterm([num 1 2 phi_2{i,j}],0.5*kappa_2,1); 
            lmiterm([num 1 3 -K{j}],1,Eb{i}');    
            lmiterm([num 2 2 M_2{i,j}],-1,1);
            lmiterm([num 2 4 Psi],1,Db{i});  
            lmiterm([num 3 3 0],-2*rho_3);
            lmiterm([num 3 3 Gamma_3{i,j}],rho_3*rho_3,1);
            lmiterm([num 4 4 0],-2*rho_4);
            lmiterm([num 4 4 Gamma_4{i,j}],rho_4*rho_4,1);     
    end
end
%% 
for i = 1:r
    for j = 1:r
            num = num +1;
            lmiterm([num 1 1 M_3{i,j}],1,1);
            lmiterm([num 1 1 W_3{i,j}],-1,1,'s');
            lmiterm([num 1 2 -W_3{i,j}],1,1); 
            lmiterm([num 1 2 phi_3{i,j}],0.5*kappa_3,1); 
            lmiterm([num 1 3 0],Ea{i}');    
            lmiterm([num 2 2 M_3{i,j}],-1,1);
            lmiterm([num 2 4 P],Da{i}',E{i});
            lmiterm([num 3 3 0],-2*rho_5);
            lmiterm([num 3 3 Gamma_5{i,j}],rho_5*rho_5,1);
            lmiterm([num 4 4 0],-2*rho_6);
            lmiterm([num 4 4 Gamma_6{i,j}],rho_6*rho_6,1);     
    end
end
%% 
for i = 1:r
    for j = 1:r
            num = num +1;
            lmiterm([num 1 1 M_4{i,j}],1,1);
            lmiterm([num 1 1 W_4{i,j}],-1,1,'s');
            lmiterm([num 1 2 -W_4{i,j}],1,1); 
            lmiterm([num 1 2 phi_4{i,j}],0.5*kappa_4,1); 
            lmiterm([num 1 3 -K{j}],1,Eb{i}'); 
            lmiterm([num 2 2 M_4{i,j}],-1,1);
            lmiterm([num 2 4 P],1,Db{i});  
            lmiterm([num 3 3 0],-2*rho_7);
            lmiterm([num 3 3 Gamma_7{i,j}],rho_7*rho_7,1);
            lmiterm([num 4 4 0],-2*rho_8);
            lmiterm([num 4 4 Gamma_8{i,j}],rho_8*rho_8,1);     
    end
end
%% 
for i = 1:r
    for j = 1:r
            num = num +1;
            lmiterm([num 1 1 P],-1,1);
            lmiterm([num 1 1 phi_1{i}],-kappa_1,1);  
            lmiterm([num 1 1 phi_2{i}],-kappa_2,1); 
            lmiterm([num 1 3 0],A{i});
            lmiterm([num 1 3 K{j}],B{i},1);
            lmiterm([num 1 4 0],C2{i}');
            lmiterm([num 2 2 P],E{i}',E{i});
            lmiterm([num 2 2 gamma_2],-1,1); 
            lmiterm([num 2 2 phi_1{i}],-kappa_1,1);  
            lmiterm([num 2 2 phi_2{i}],-kappa_2,1); 
            lmiterm([num 3 3 Psi],-2,1,'s');   
            lmiterm([num 3 3 Omega_1],1,1,'s'); 
            lmiterm([num 3 3 Omega_2],1,1,'s'); 
            lmiterm([num 4 4 0],-1);   
    end
end
%% 
for i = 1:r
    for j = 1:r
            num = num +1;
            lmiterm([num 1 1 phi_5{i}],-kappa_5,1);
            lmiterm([num 1 2 0],A{i}');
            lmiterm([num 1 2 -K{j}],1,B{i}'); 
            lmiterm([num 2 2 phi_5{i}],-kappa_5,1);
    end
end
%% 
lmisys = getlmis;
dim = decnbr(lmisys);
c = zeros(dim,1);
c(1) = 1;
c(2) = 1;
options = [0 0 0 0 0];
[copt,xopt] = mincx(lmisys,c,options);
%% 
for j=1:r    
    Z{j} = dec2mat(lmisys,xopt,Z{j});
    K{j} = dec2mat(lmisys,xopt,K{j});
end
P = dec2mat(lmisys,xopt,P);
gamma_2 = dec2mat(lmisys,xopt,gamma_2);
gamma = sqrt(gamma_2);